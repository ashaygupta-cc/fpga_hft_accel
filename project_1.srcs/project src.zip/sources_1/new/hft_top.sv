`timescale 1ns / 1ps

module hft_top #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer BAUD_RATE   = 9600
)(
    input  logic clk,
    input  logic cpu_resetn,
    input  logic uart_rxd,
    output logic uart_txd,

    output logic [15:0] best_bid_price,
    output logic [15:0] best_bid_qty,
    output logic [15:0] best_ask_price,
    output logic [15:0] best_ask_qty
);

    logic rst;
    assign rst = ~cpu_resetn;

    logic       rx_valid;
    logic [7:0] rx_data;

    logic        cmd_valid;
    logic [1:0]  cmd_op;
    logic        cmd_side;
    logic [15:0] cmd_price;
    logic [15:0] cmd_qty;

    logic        tx_start;
    logic [7:0]  tx_data;
    logic        tx_busy;

    logic        snap_start;
    logic        snap_busy;

    // delay cmd_valid by 1 clock so book outputs are already updated
    always_ff @(posedge clk or posedge rst) begin
        if (rst) begin
            snap_start <= 1'b0;
        end else begin
            snap_start <= cmd_valid;
        end
    end

    uart_rx #(
        .CLK_FREQ(CLK_FREQ_HZ),
        .BAUD_RATE(BAUD_RATE)
    ) u_rx (
        .clk(clk),
        .rst(rst),
        .rx(uart_rxd),
        .rx_data(rx_data),
        .rx_valid(rx_valid)
    );

    cmd_parser u_parser (
        .clk(clk),
        .rst(rst),
        .rx_valid(rx_valid),
        .rx_data(rx_data),
        .cmd_valid(cmd_valid),
        .cmd_op(cmd_op),
        .cmd_side(cmd_side),
        .cmd_price(cmd_price),
        .cmd_qty(cmd_qty)
    );

    order_book #(
        .MAX_LEVELS(8),
        .PRICE_W(16),
        .QTY_W(16)
    ) u_book (
        .clk(clk),
        .rst(rst),
        .cmd_valid(cmd_valid),
        .cmd_op(cmd_op),
        .cmd_side(cmd_side),
        .cmd_price(cmd_price),
        .cmd_qty(cmd_qty),
        .best_bid_price(best_bid_price),
        .best_bid_qty(best_bid_qty),
        .best_ask_price(best_ask_price),
        .best_ask_qty(best_ask_qty)
    );

    book_tx_fsm u_snap_tx (
        .clk(clk),
        .rst(rst),
        .start(snap_start),
        .best_bid_price(best_bid_price),
        .best_bid_qty(best_bid_qty),
        .best_ask_price(best_ask_price),
        .best_ask_qty(best_ask_qty),
        .tx_busy(tx_busy),
        .tx_start(tx_start),
        .tx_data(tx_data),
        .busy(snap_busy)
    );

    uart_tx #(
        .CLK_FREQ(CLK_FREQ_HZ),
        .BAUD_RATE(BAUD_RATE)
    ) u_tx (
        .clk(clk),
        .rst(rst),
        .tx_start(tx_start),
        .tx_data(tx_data),
        .tx(uart_txd),
        .tx_busy(tx_busy)
    );

endmodule